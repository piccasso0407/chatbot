import streamlit as st
from PyPDF2 import PdfReader
import docx
import streamlit as st
import tiktoken
from loguru import logger
import time
import concurrent.futures
import pandas as pd
import json
import os

from langchain.chains import ConversationalRetrievalChain
from langchain.document_loaders import PyPDFLoader, Docx2txtLoader, UnstructuredPowerPointLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.memory import ConversationBufferMemory
from langchain.vectorstores import FAISS
from langchain.memory import StreamlitChatMessageHistory
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain_openai import ChatOpenAI
# 사이드바 및 폰트 스타일 설정
# st.markdown(
#     """
#     <style>
#     /* 사이드바 배경색 설정 */
#     [data-testid="stSidebar"] {
#         background-color: #FFFFDAB9;
#     }

#     /* 전체 페이지 폰트를 Pretendard, sans-serif로 설정 */
#     body {
#         font-family: Pretendard, sans-serif;
#     }

#     /* 텍스트 에어리어의 커스텀 스타일 */
#     .custom-textarea {
#         background-color: #FFFFDAB9;  /* 배경색 변경 */
#         color: black;  /* 텍스트 색상 */
#         padding: 10px;
#         border-radius: 5px;
#         border: 1px solid gray;
#     }
#     </style>
#     """, unsafe_allow_html=True
# )

file_paths = [ "./data/recipes.docx"]  # 파일 경로 리스트

# PDF 파일 읽기 함수
def read_pdf(file_path):
    try:
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return text
    except Exception as e:
        return f"Error reading PDF: {e}"

# DOCX 파일 읽기 함수
def read_docx(file_path):
    try:
        doc = docx.Document(file_path)
        full_text = []
        for para in doc.paragraphs:
            full_text.append(para.text)
        return '\n'.join(full_text)
    except Exception as e:
        return f"Error reading DOCX: {e}"

st.subheader('RAG 구축과정')
st.write("고혈압 관리에 영향을 미치는 요인 분석.pdf")
st.markdown(
"""
<p style='font-size:10px;'>
출처: <a href="https://www.researchgate.net/profile/Il-Park-2/publication/263633618_Related_Factors_of_Awareness_Treatment_and_Control_of_Hypertension_in_Korea_Using_the_Fourth_Korea_National_Health_Nutrition_Examination_Survey/links/54f5a3510cf2eed5d738fa48/Related-Factors-of-Awareness-Treatment-and-Control-of-Hypertension-in-Korea-Using-the-Fourth-Korea-National_Health_Nutrition_Examination_Survey.pdf">
연구 링크</a>
</p>
""", 
unsafe_allow_html=True
)
# 파일 내용 읽기 및 표시
for file_path in file_paths:

    if file_path.endswith('.pdf'):
        try:
            pdf_text = read_pdf(file_path)
            st.text_area("PDF Text", pdf_text, height=300)
        except Exception as e:
            st.error(f"Error reading {file_path}: {e}")

    elif file_path.endswith('.docx'):
        st.write("reecipes.docx")
        try:
            docx_text = read_docx(file_path)
            st.text_area("DOCX Text", docx_text, height=300)
        except Exception as e:
            st.error(f"Error reading {file_path}: {e}")

#텍스트 나누기
st.write("텍스트 추출 작업")

with st.expander("코드보기"):
    st.code("""
def get_text(file_paths):
    doc_list = []
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(process_file, path) for path in file_paths]
        results = [future.result() for future in concurrent.futures.as_completed(futures)]
        doc_list = [doc for sublist in results for doc in sublist]
    return doc_list

def process_file(file_path):
    file_name = file_path
    if '.pdf' in file_name:
        loader = PyPDFLoader(file_name)
    elif '.docx' in file_name:
        loader = Docx2txtLoader(file_name)
    elif '.pptx' in file_name:
        loader = UnstructuredPowerPointLoader(file_name)
    else:
        return []
    documents = loader.load_and_split()
    return documents

files_text = get_text(file_paths)
    """, language='python')




def get_text(file_paths):
    doc_list = []
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(process_file, path) for path in file_paths]
        results = [future.result() for future in concurrent.futures.as_completed(futures)]
        doc_list = [doc for sublist in results for doc in sublist]
    return doc_list

def process_file(file_path):
    file_name = file_path
    if '.pdf' in file_name:
        loader = PyPDFLoader(file_name)
    elif '.docx' in file_name:
        loader = Docx2txtLoader(file_name)
    elif '.pptx' in file_name:
        loader = UnstructuredPowerPointLoader(file_name)
    else:
        return []
    documents = loader.load_and_split()
    return documents

files_text = get_text(file_paths)

st.write("추출 결과")
st.write(files_text)


st.write("토큰 길이 계산하기")
with st.expander("코드보기"):
    st.code("""
def tiktoken_len(text):
    tokenizer = tiktoken.get_encoding("cl100k_base")
    tokens = tokenizer.encode(text)
    return len(tokens)
    """, language='python')

def tiktoken_len(text):
    tokenizer = tiktoken.get_encoding("cl100k_base")
    tokens = tokenizer.encode(text)
    return len(tokens)



# tiktoken_len을 사용하여 첫 번째 파일의 토큰 길이 계산
token_length = tiktoken_len(files_text[0].page_content)
st.write(f"첫번째 토큰의 길이: {token_length}")


st.write("청크 나누기")
with st.expander("코드보기"):
    st.code("""
def get_text_chunks(_text, chunk_size, chunk_overlap):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=tiktoken_len
    )
    chunks = text_splitter.split_documents(_text)
    return chunks
    """, language='python')

st.write("임베딩")
with st.expander("코드보기"):
    st.code("""
@st.cache_resource
def get_vectorstore(_text_chunks, selected_model):
    embeddings = HuggingFaceEmbeddings(
        model_name=selected_model,  # 사용자가 선택한 모델
        model_kwargs={'device': 'cuda'},
        encode_kwargs={'normalize_embeddings': True}
    )
    vectordb = FAISS.from_documents(_text_chunks, embeddings)
    return vectordb
vectorstore = get_vectorstore(text_chunks, selected_model)
    """, language='python')


# 여러 임베딩 모델 선택을 위한 리스트
embedding_options = [
    "jhgan/ko-sroberta-multitask",
    "sentence-transformers/all-MiniLM-L6-v2",
    "BAAI/bge-small-en"
]

# 사용자가 선택할 수 있도록 selectbox 추가
selected_model = st.selectbox("임베딩 모델을 선택하세요:", embedding_options)

# 청크 사이즈와 오버랩 값을 입력받기 위한 슬라이더 추가
chunk_size = st.slider("청크 사이즈를 선택하세요:", min_value=100, max_value=5000, value=1000, step=100)
chunk_overlap = st.slider("청크 오버랩을 선택하세요:", min_value=0, max_value=5000, value=400, step=100)

# 텍스트 청크 분할 함수
def get_text_chunks(_text, chunk_size, chunk_overlap):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=tiktoken_len
    )
    chunks = text_splitter.split_documents(_text)
    return chunks

st.button("실행")
if files_text:
    text_chunks = get_text_chunks(files_text, chunk_size, chunk_overlap)
    
    # 첫 번째 청크만 출력 (필요에 따라 더 많은 청크를 출력할 수 있음)
    if text_chunks:
        st.text_area("첫 번째 청크 내용:", text_chunks[0].page_content, height=300)
    else:
        st.write("청크가 생성되지 않았습니다.")
else:
    st.write("파일에서 텍스트를 가져오지 못했습니다.")

st.write("벡터스토어 생성하기")
with st.expander("코드보기"):
    st.code("""
def get_vectorstore(_text_chunks, selected_model):
    embeddings = HuggingFaceEmbeddings(
        model_name=selected_model,  # 사용자가 선택한 모델
        model_kwargs={'device': 'cuda'},
        encode_kwargs={'normalize_embeddings': True}
    )
    vectordb = FAISS.from_documents(_text_chunks, embeddings)
    return vectordb

# 단어를 입력받아 해당 벡터를 추출하는 함수
def get_word_vector(query, selected_model):
    embeddings = HuggingFaceEmbeddings(model_name=selected_model)
    query_embedding = embeddings.embed_query(query)
    return query_embedding  # 임베딩 벡터(숫자 배열) 반환
    """, language='python')

# 벡터 스토어를 생성하는 함수
@st.cache_resource
def get_vectorstore(_text_chunks, selected_model):
    embeddings = HuggingFaceEmbeddings(
        model_name=selected_model,  # 사용자가 선택한 모델
        model_kwargs={'device': 'cuda'},
        encode_kwargs={'normalize_embeddings': True}
    )
    vectordb = FAISS.from_documents(_text_chunks, embeddings)
    return vectordb
vectorstore = get_vectorstore(text_chunks, selected_model)


# 단어를 입력받아 해당 벡터를 추출하는 함수
def get_word_vector(query, selected_model):
    embeddings = HuggingFaceEmbeddings(model_name=selected_model)
    query_embedding = embeddings.embed_query(query)
    return query_embedding  # 임베딩 벡터(숫자 배열) 반환


# 임베딩 벡터 추출
query = st.text_input("벡터를 확인할 단어를 입력하세요:")

if query:
    # 입력한 단어의 벡터(숫자 배열) 추출
    word_vector = get_word_vector(query, selected_model)
    
    # 벡터의 차원 확인
    vector_dimension = len(word_vector)
    
    # 벡터의 앞 5개 값 추출
    first_five_values = word_vector[:5]
    
    # 벡터의 차원과 앞 5개 값 출력
    st.write(f"'{query}'의 벡터 차원: {vector_dimension}차원")
    st.write(f"벡터의 앞 5개 값: {first_five_values}")

        # 유사한 5개의 벡터 검색
    if vectorstore:
        similar_documents = vectorstore.similarity_search_by_vector(word_vector, k=1)
        
        st.write(f"'{query}'와 유사한 1개의 문서:")
        for i, doc in enumerate(similar_documents):
            st.text_area(f"문장 내용", doc.page_content, height=100)

st.write("파이프라인 만들기")
with st.expander("코드보기"):
    st.code("""
def get_conversation_chain(_vectorstore):
    llm = ChatOpenAI(
        base_url="http://localhost:1234/v1",  # Update with the actual URL of your LM Studio server
        api_key="lm-studio",  # Replace with your actual API key
        model="teddylee777/EEVE-Korean-Instruct-10.8B-v1.0-gguf",  # Update with the correct model name if different
        temperature=0.7
    )

    conversation_chain = ConversationalRetrievalChain.from_llm(
        llm=llm, 
        chain_type="stuff", 
        retriever=_vectorstore.as_retriever(search_type='mmr', verbose=True), 
        memory=ConversationBufferMemory(memory_key='chat_history', return_messages=True, output_key='answer'),
        get_chat_history=lambda h: h,
        return_source_documents=True,
        verbose=True
    )
    return conversation_chain
    """, language='python')