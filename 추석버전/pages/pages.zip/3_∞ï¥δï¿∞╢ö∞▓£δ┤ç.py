import streamlit as st
import tiktoken
from loguru import logger
import time
import concurrent.futures
import pandas as pd
import json
import os
from transformers import AutoTokenizer
from langchain.chains import ConversationalRetrievalChain
from langchain.document_loaders import PyPDFLoader, Docx2txtLoader, UnstructuredPowerPointLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.memory import ConversationBufferMemory
from langchain.vectorstores import FAISS
from langchain.memory import StreamlitChatMessageHistory
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain_openai import ChatOpenAI

# 파일 경로를 입력
file_paths = ["data/고혈압 관리에 영향을 미치는 요인 분석.pdf", "data/싱거운음식.docx"]  # 파일 경로 리스트

# 설문조사 결과로 저장된 JSON 파일 경로 설정
survey_json_file_path = "survey_results/survey_results.json"  # 설문조사 결과가 저장된 파일 경로

def main():
    st.set_page_config(
        page_title="RECIPES",
        page_icon=":books:"
    )

    st.title("식단추천 해드림 :☀️🍝:")

    # 사이드바에서 설문조사 JSON 파일 읽기 및 데이터프레임 표시
    with st.sidebar:
        st.header("Survey Results")
    
    if st.sidebar.button("Clear Cache and Reset Session"):
        clear_cache_and_reset()
        
        # 설문조사 JSON 파일을 불러오는 로직
        if os.path.exists(survey_json_file_path):
            with open(survey_json_file_path, "r") as json_file:
                json_data = json.load(json_file)  # JSON 파일을 로드

                # JSON 데이터를 데이터프레임으로 변환하여 사이드바에 표시
                df = pd.json_normalize(json_data)
                st.dataframe(df)

                # 사용자가 JSON 데이터를 기반으로 질문을 선택할 수 있도록 제공
                question_options = [f"What is {col}?" for col in df.columns]
                selected_question = st.selectbox("Choose a question to ask", question_options)

                if st.button("Ask Question"):
                    if 'messages' not in st.session_state:
                        st.session_state['messages'] = []
                    st.session_state['messages'].append({"role": "user", "content": selected_question})
                    st.experimental_rerun()
        else:
            st.error("Survey results JSON file not found. Please check the file path.")

    # 이전 채팅 기록 출력
    if 'messages' not in st.session_state:
        st.session_state['messages'] = [{"role": "assistant", 
                                         "content": "안녕하세요! 식단추천봇입니다!"}]

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    history = StreamlitChatMessageHistory(key="chat_messages")

    # 파일을 코드에서 바로 처리
    files_text = get_text(file_paths)
    text_chunks = get_text_chunks(files_text)
    vectorstore = get_vectorstore(text_chunks)
    st.session_state.conversation = get_conversation_chain(vectorstore)

    # Chat logic
    if query := st.chat_input("질문을 입력해주세요."):
        st.session_state.messages.append({"role": "user", "content": query})

        with st.chat_message("user"):
            st.markdown(query)

        with st.chat_message("assistant"):
            chain = st.session_state.conversation

            with st.spinner("Thinking..."):
                result = chain({"question": query})
                response = result['answer']
                source_documents = result['source_documents']

                # 스트리밍을 위한 빈 요소 생성
                response_container = st.empty()

                # 스트리밍 구현: 일정량의 텍스트를 한 번에 출력
                chunk_size = 5  # 한번에 출력할 텍스트 길이
                for i in range(0, len(response), chunk_size):
                    response_container.markdown(response[:i + chunk_size], unsafe_allow_html=True)
                    time.sleep(0.05)  # 출력 속도 조절

                with st.expander("참고 문서 확인"):
                    for doc in source_documents:
                        st.markdown(doc.metadata['source'], help=doc.page_content)

        # Add assistant message to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})

def clear_cache_and_reset():
    st.cache_data.clear()
    st.cache_resource.clear()
    st.session_state.clear()  # 세션 상태를 초기화하여 채팅 기록도 제거

def tiktoken_len(text):
    tokenizer = tiktoken.get_encoding("cl100k_base")
    tokens = tokenizer.encode(text)
    return len(tokens)
# def truncate_text(text):
#     tokenizer = AutoTokenizer.from_pretrained("jhgan/ko-sroberta-multitask")
#     tokens = tokenizer(text, truncation=True, return_tensors="pt")
#     return len(tokens)

@st.cache_data
def get_text(file_paths):
    doc_list = []
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(process_file, path) for path in file_paths]
        results = [future.result() for future in concurrent.futures.as_completed(futures)]
        doc_list = [doc for sublist in results for doc in sublist]
    return doc_list

def process_file(file_path):
    file_name = file_path
    if '.pdf' in file_name:
        loader = PyPDFLoader(file_name)
    elif '.docx' in file_name:
        loader = Docx2txtLoader(file_name)
    elif '.pptx' in file_name:
        loader = UnstructuredPowerPointLoader(file_name)
    else:
        return []
    documents = loader.load_and_split()
    return documents

@st.cache_data
def get_text_chunks(_text):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=256,
        chunk_overlap=20,
        length_function=tiktoken_len
    )
    chunks = text_splitter.split_documents(_text)
    return chunks

@st.cache_resource
def get_vectorstore(_text_chunks):
    embeddings = HuggingFaceEmbeddings(
        model_name="jhgan/ko-sroberta-multitask",  # 임베딩 모델 고정
        model_kwargs={'device': 'cuda'},
        encode_kwargs={'normalize_embeddings': True}
    )
    vectordb = FAISS.from_documents(_text_chunks, embeddings)
    return vectordb

@st.cache_resource
def get_conversation_chain(_vectorstore):
    llm = ChatOpenAI(
        base_url="http://localhost:1234/v1",  # Update with the actual URL of your LM Studio server
        api_key="lm-studio",  # Replace with your actual API key
        model="teddylee777/EEVE-Korean-Instruct-10.8B-v1.0-gguf",  # Update with the correct model name if different
        temperature=0.2
    )

    retriever = _vectorstore.as_retriever(
        search_type='mmr', 
        search_kwargs={"k": 3},  # MMR 파라미터 설정
        verbose=True
    )

    conversation_chain = ConversationalRetrievalChain.from_llm(
        llm=llm, 
        chain_type="stuff", 
        retriever=retriever, 
        memory=ConversationBufferMemory(memory_key='chat_history', return_messages=True, output_key='answer'),
        get_chat_history=lambda h: h,
        return_source_documents=True,
        verbose=True
    )
    return conversation_chain
if __name__ == '__main__':
    main()
