import streamlit as st
import tiktoken
from loguru import logger
import time
import concurrent.futures
from datasets import load_dataset
from transformers import AutoTokenizer
from langchain.chains import ConversationalRetrievalChain
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.memory import ConversationBufferMemory
from langchain.vectorstores import FAISS
from langchain.memory import StreamlitChatMessageHistory
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain_openai import ChatOpenAI
from langchain.docstore.document import Document

def main():
    st.set_page_config(
        page_title="Hugging Face RAG",
        page_icon=":books:"
    )

    st.title("_Hugging Face Dataset QA Chat_ :books:")

    # 사이드바에서 Hugging Face 데이터셋을 선택
    with st.sidebar:
        st.header("Load Dataset")
        dataset_name = st.text_input("Enter Hugging Face Dataset Name", "squad")
        dataset_split = st.selectbox("Choose Dataset Split", ["train", "validation", "test"])
        embedding_model = st.selectbox("Choose Embedding Model", [
            "jhgan/ko-sroberta-multitask",
            "sentence-transformers/all-MiniLM-L6-v2",
            "BAAI/bge-small-en",
        ])
        process = st.button("Load and Process Dataset")

        if process:
            # Hugging Face 데이터셋 로드
            qa_data = load_dataset(dataset_name, split=dataset_split)
            st.write(qa_data)

            # 데이터에서 텍스트 추출 후 벡터 스토어로 변환
            text_chunks = get_text_chunks(qa_data)
            vectorstore = get_vectorstore(text_chunks, embedding_model)
            st.session_state.conversation = get_conversation_chain(vectorstore)
            st.session_state.processComplete = True

    # 캐시를 지우는 버튼 추가
    if st.sidebar.button("Clear Cache and Reset Session"):
        clear_cache_and_reset()

    # 이전 채팅 기록 출력
    if 'messages' not in st.session_state:
        st.session_state['messages'] = [{"role": "assistant", 
                                         "content": "안녕하세요! Hugging Face 데이터셋을 사용한 문서 검색 봇입니다. 데이터를 로드하고 질문을 입력해보세요!"}]

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    history = StreamlitChatMessageHistory(key="chat_messages")

    # Chat logic
    if query := st.chat_input("질문을 입력해주세요."):
        st.session_state.messages.append({"role": "user", "content": query})

        with st.chat_message("user"):
            st.markdown(query)

        with st.chat_message("assistant"):
            chain = st.session_state.conversation

            with st.spinner("Thinking..."):
                result = chain({"question": query})
                response = result['answer']
                source_documents = result['source_documents']

                # 스트리밍을 위한 빈 요소 생성
                response_container = st.empty()

                # 스트리밍 구현: 일정량의 텍스트를 한 번에 출력
                chunk_size = 5  # 한번에 출력할 텍스트 길이
                for i in range(0, len(response), chunk_size):
                    response_container.markdown(response[:i + chunk_size], unsafe_allow_html=True)
                    time.sleep(0.05)  # 출력 속도 조절

        # Add assistant message to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})




def clear_cache_and_reset():
    st.cache_data.clear()
    st.cache_resource.clear()
    st.session_state.clear()  # 세션 상태를 초기화하여 채팅 기록도 제거
    st.experimental_rerun()  # 페이지를 다시 로드하여 초기화된 상태로 만듦

def tiktoken_len(text):
    tokenizer = tiktoken.get_encoding("cl100k_base")
    tokens = tokenizer.encode(text)
    return len(tokens)

@st.cache_data
def get_text_chunks(_dataset):
    # 'input'과 'response' 필드를 모두 결합하여 Document 객체에 저장
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=256,
        chunk_overlap=20,
        length_function=tiktoken_len
    )

    # 'input'과 'response' 필드를 결합하여 Document 객체로 변환
    documents = [
        Document(page_content=f"Input: {example['input']}\nResponse: {example['response']}")
        for example in _dataset
    ]

    # 문서들을 청크로 나누기
    chunks = text_splitter.split_documents(documents)
    return chunks

@st.cache_resource
def get_vectorstore(_text_chunks, selected_model):
    embeddings = HuggingFaceEmbeddings(
        model_name=selected_model,
        model_kwargs={'device': 'cuda'},
        encode_kwargs={'normalize_embeddings': True}
    )
    
    # Document 객체에서 텍스트만 추출
    texts = [doc.page_content for doc in _text_chunks]  # Document 객체에서 텍스트 추출
    
    # FAISS에 텍스트 데이터 전달
    vectordb = FAISS.from_texts(texts, embeddings)
    
    return vectordb

@st.cache_resource
def get_conversation_chain(_vectorstore):
    llm = ChatOpenAI(
        base_url="http://localhost:1234/v1",  # Update with the actual URL of your LM Studio server
        api_key="lm-studio",  # Replace with your actual API key
        model="teddylee777/EEVE-Korean-Instruct-10.8B-v1.0-gguf",  # Update with the correct model name if different
        temperature=0.2
    )

    retriever = _vectorstore.as_retriever(
        search_type='mmr', 
        search_kwargs={"k": 3},  # MMR 파라미터 설정
        verbose=True
    )

    conversation_chain = ConversationalRetrievalChain.from_llm(
        llm=llm, 
        chain_type="stuff", 
        retriever=retriever, 
        memory=ConversationBufferMemory(memory_key='chat_history', return_messages=True, output_key='answer'),
        get_chat_history=lambda h: h,
        return_source_documents=True,
        verbose=True
    )
    return conversation_chain

if __name__ == '__main__':
    main()
